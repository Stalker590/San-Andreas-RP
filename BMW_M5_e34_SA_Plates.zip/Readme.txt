BMW M5 E34 1990 

GTA Vice City credits: Zlatko (NFS4) & RusLev 
GTA San Andreas credits: X-Plosion/liam247/SeaNorris/swmand4 

v0.1 Beta - 

Two TXDs in zip 
Can't be modded yet 
Fixing bugs.

Handing.cfg:

SENTINEL	1400.0	3000.0	2.0	0.0	-0.2	-0.24	70	0.75	0.86	0.48	5	155.0	26.0	5.0	R	P	8.0	0.52	0	30.0	1.0	0.20	0.0	0.25	-0.10	0.5	0.3	0.40	0.54	105000	40002004	208000	0	0	1

Vehicles.ide:

405, 	sentinel, 	sentinel, 	car, 		SENTINEL, 	SENTINL, 	null,	executive, 	2, 	7,	0,		-1, 0.87, 0.87,	        0

carcols:
Add these below #126 (you'll need to change numbers)

26,235,63                       # 141 lama orange
        green
120,76,5                        # 142 lama orange
        orange
207,189,151                     # 143 lotus white
        white
29,12,48                        # 144 violet blue
        blue

then this:

sentinel, 11,1, 24,1, 36,1, 40,1, 75,1, 91,1, 123,1, 4,1 140,140 141,141 143,143 144,144

carmods.dat:

sentinel, nto_b_l, nto_b_s, nto_b_tw

